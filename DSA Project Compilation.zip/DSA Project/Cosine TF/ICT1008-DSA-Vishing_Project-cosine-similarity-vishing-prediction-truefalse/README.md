# ICT1008-DSA-Vishing_Project
Vishing Defender is a tool designed to combat voice phishing scams. It educates users about vishing characteristics, identifies potential threats from reported calls, offers advice during an attack, and features an easy-to-use GUI. Your safety is our priority!

#Notes for Cosine Sim#
Don't use DSA_Project_Vishing_Prog_2.py. That one cannot work. The only working one is DSA_Proj...Prog_1.py
