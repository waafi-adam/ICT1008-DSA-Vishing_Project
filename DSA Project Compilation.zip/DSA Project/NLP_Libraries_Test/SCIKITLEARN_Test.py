import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.pipeline import Pipeline
from sklearn.base import BaseEstimator, TransformerMixin
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

# Download stopwords and WordNet lemmatizer data
nltk.download('stopwords')
nltk.download('wordnet')

# Define a custom transformer for text preprocessing
class TextPreprocessor(BaseEstimator, TransformerMixin):
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        preprocessed_X = []
        for sentence in X:
            tokens = word_tokenize(sentence.lower())
            tokens = [self.lemmatizer.lemmatize(token) for token in tokens if token.isalpha()]
            tokens = [token for token in tokens if token not in self.stop_words]
            preprocessed_X.append(' '.join(tokens))
        return preprocessed_X

# Define a custom transformer for calculating cosine similarity
class CosineSimilarityTransformer(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return cosine_similarity(X)

# Define a custom transformer for extracting maximum similarity score
class MaxSimilarityTransformer(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X.max(axis=1)

# Load the fraud dataset from CSV
dataset = pd.read_csv('fraudtest.csv')

# Extract the text column
fraud_sentences = dataset['text'].tolist()

# Define the reference sentence
reference_sentence = "i need some money, please send me"

# Preprocess the reference sentence
preprocessor = TextPreprocessor()
preprocessed_reference = preprocessor.transform([reference_sentence])

# Preprocess the fraud sentences
preprocessed_fraud_sentences = preprocessor.transform(fraud_sentences)

# Create a pipeline for vectorization, similarity calculation, and finding maximum similarity
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer()),
    ('cosine_sim', CosineSimilarityTransformer()),
    ('max_sim', MaxSimilarityTransformer())
])

# Fit the pipeline on preprocessed fraud sentences
pipeline.fit(preprocessed_fraud_sentences)

# Calculate the similarity between the reference sentence and fraud sentences
similarity_scores = pipeline.transform(preprocessed_reference)

# Get the maximum similarity score and its index
max_similarity = similarity_scores[0]
max_index = max_similarity.argmax()

# Print the maximum similarity score and the corresponding fraud sentence
print("Similarity Score: {:.2f}%".format(max_similarity * 100))
print("Potential Vishing Sentence: ", fraud_sentences[max_index])
