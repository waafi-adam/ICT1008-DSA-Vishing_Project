import csv
import nltk
from nltk.corpus import stopwords
from nltk.metrics.distance import edit_distance
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

def preprocess_text(text):
    # Tokenize the text
    tokens = word_tokenize(text.lower())

    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [token for token in tokens if token not in stop_words]

    # Lemmatize the tokens
    lemmatizer = WordNetLemmatizer()
    tokens = [lemmatizer.lemmatize(token) for token in tokens]

    # Join the tokens back into a string
    preprocessed_text = ' '.join(tokens)
    return preprocessed_text

def calculate_similarity(reference_sentence, dataset):
    reference_sentence = preprocess_text(reference_sentence)
    reference_tokens = word_tokenize(reference_sentence)

    similarity_scores = []

    for transcript in dataset:
        transcript = preprocess_text(transcript)
        transcript_tokens = word_tokenize(transcript)

        distance = edit_distance(reference_tokens, transcript_tokens)
        similarity_score = 1 - (distance / max(len(reference_tokens), len(transcript_tokens)))
        similarity_scores.append(similarity_score)

    average_similarity = sum(similarity_scores) / len(similarity_scores)
    return average_similarity * 100

def load_dataset(file_path):
    dataset = []
    with open(file_path, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            dataset.append(row['text'])
    return dataset

def main():
    reference_sentence = "I am IRS, give me password and email"
    dataset = load_dataset('fraudtest.csv')
    similarity_percentage = calculate_similarity(reference_sentence, dataset)
    print("Similarity Percentage: {:.2f}%".format(similarity_percentage))

if __name__ == '__main__':
    main()
