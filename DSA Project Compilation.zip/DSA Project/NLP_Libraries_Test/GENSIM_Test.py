import pandas as pd
from gensim import corpora, models, similarities
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Load the fraud dataset from CSV
fraud_dataset = pd.read_csv('fraudtest.csv')

# Load the non-fraud dataset from CSV
nonfraud_dataset = pd.read_csv('nonfraudtest.csv')

# Extract the text column from the fraud dataset
fraud_sentences = fraud_dataset['text'].tolist()

# Extract the text column from the non-fraud dataset
nonfraud_sentences = nonfraud_dataset['text'].tolist()

# Define the reference sentence
reference_sentence = "I am IRS, give me password and email"

# Preprocess the reference sentence
stop_words = set(stopwords.words('english'))
reference_tokens = [token.lower() for token in word_tokenize(reference_sentence) if token.lower() not in stop_words and token.isalpha()]
preprocessed_reference = " ".join(reference_tokens)

# Preprocess the fraud sentences
preprocessed_fraud_sentences = []
for sentence in fraud_sentences:
    tokens = [token.lower() for token in word_tokenize(sentence) if token.lower() not in stop_words and token.isalpha()]
    preprocessed_fraud_sentences.append(tokens)

# Preprocess the non-fraud sentences
preprocessed_nonfraud_sentences = []
for sentence in nonfraud_sentences:
    tokens = [token.lower() for token in word_tokenize(sentence) if token.lower() not in stop_words and token.isalpha()]
    preprocessed_nonfraud_sentences.append(tokens)

# Create a dictionary and corpus for the fraud sentences
fraud_dictionary = corpora.Dictionary(preprocessed_fraud_sentences)
fraud_corpus = [fraud_dictionary.doc2bow(tokens) for tokens in preprocessed_fraud_sentences]

# Create a dictionary and corpus for the non-fraud sentences
nonfraud_dictionary = corpora.Dictionary(preprocessed_nonfraud_sentences)
nonfraud_corpus = [nonfraud_dictionary.doc2bow(tokens) for tokens in preprocessed_nonfraud_sentences]

# Transform the reference sentence to the TF-IDF vector representation
reference_vec = fraud_dictionary.doc2bow(reference_tokens)
tfidf = models.TfidfModel(fraud_corpus + nonfraud_corpus)
reference_tfidf = tfidf[reference_vec]

# Create similarity index for fraud sentences
fraud_index = similarities.MatrixSimilarity(tfidf[fraud_corpus])

# Create similarity index for non-fraud sentences
nonfraud_index = similarities.MatrixSimilarity(tfidf[nonfraud_corpus])

# Calculate the similarity scores between the reference sentence and fraud sentences
fraud_similarity_scores = fraud_index[reference_tfidf]

# Calculate the similarity scores between the reference sentence and non-fraud sentences
nonfraud_similarity_scores = nonfraud_index[reference_tfidf]

# Get the maximum similarity score and its index for fraud dataset
max_similarity_fraud = max(fraud_similarity_scores)
max_index_fraud = fraud_similarity_scores.tolist().index(max_similarity_fraud)

# Get the maximum similarity score and its index for non-fraud dataset
max_similarity_nonfraud = max(nonfraud_similarity_scores)
max_index_nonfraud = nonfraud_similarity_scores.tolist().index(max_similarity_nonfraud)

# Determine if the reference sentence is a potential vishing attempt or a genuine phone call
if max_similarity_fraud > max_similarity_nonfraud:
    print("Potential Vishing Sentence")
    print("Similarity Score: {:.2f}%".format(max_similarity_fraud * 100))
    print("Sentence: ", fraud_sentences[max_index_fraud])
else:
    print("Genuine Phone Call")
    print("Similarity Score: {:.2f}%".format(max_similarity_nonfraud * 100))
    print("Sentence: ", nonfraud_sentences[max_index_nonfraud])
