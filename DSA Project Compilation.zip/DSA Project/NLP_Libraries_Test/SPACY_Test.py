import pandas as pd
import spacy

# Load the spaCy English model
nlp = spacy.load("en_core_web_lg")

# Load the fraud dataset from CSV
fraud_dataset = pd.read_csv('fraudtest.csv')

# Load the non-fraud dataset from CSV
nonfraud_dataset = pd.read_csv('nonfraudtest.csv')

# Extract the text column from the fraud dataset
fraud_sentences = fraud_dataset['text'].tolist()

# Extract the text column from the non-fraud dataset
nonfraud_sentences = nonfraud_dataset['text'].tolist()

# Define the reference sentence
reference_sentence = "i am irs, give me email and password"

# Preprocess the reference sentence
reference_doc = nlp(reference_sentence)
reference_tokens = [token.lemma_.lower() for token in reference_doc if not token.is_stop and token.is_alpha]
preprocessed_reference = " ".join(reference_tokens)

# Preprocess the fraud sentences
preprocessed_fraud_sentences = []
for sentence in fraud_sentences:
    doc = nlp(sentence)
    tokens = [token.lemma_.lower() for token in doc if not token.is_stop and token.is_alpha]
    preprocessed_fraud_sentences.append(" ".join(tokens))

# Preprocess the non-fraud sentences
preprocessed_nonfraud_sentences = []
for sentence in nonfraud_sentences:
    doc = nlp(sentence)
    tokens = [token.lemma_.lower() for token in doc if not token.is_stop and token.is_alpha]
    preprocessed_nonfraud_sentences.append(" ".join(tokens))

# Calculate the similarity between the reference sentence and fraud sentences
similarity_scores_fraud = []
for sentence in preprocessed_fraud_sentences:
    doc = nlp(sentence)
    similarity = reference_doc.similarity(doc)
    similarity_scores_fraud.append(similarity)

# Calculate the similarity between the reference sentence and non-fraud sentences
similarity_scores_nonfraud = []
for sentence in preprocessed_nonfraud_sentences:
    doc = nlp(sentence)
    similarity = reference_doc.similarity(doc)
    similarity_scores_nonfraud.append(similarity)

# Get the maximum similarity score and its index for fraud dataset
max_similarity_fraud = max(similarity_scores_fraud)
max_index_fraud = similarity_scores_fraud.index(max_similarity_fraud)

# Get the maximum similarity score and its index for non-fraud dataset
max_similarity_nonfraud = max(similarity_scores_nonfraud)
max_index_nonfraud = similarity_scores_nonfraud.index(max_similarity_nonfraud)

# Determine if the reference sentence is a potential vishing attempt or a genuine phone call
if max_similarity_fraud > max_similarity_nonfraud:
    print("Potential Vishing Sentence")
    print("Similarity Score: {:.2f}%".format(max_similarity_fraud * 100))
    print("Sentence: ", fraud_sentences[max_index_fraud])
else:
    print("Genuine Phone Call")
    print("Similarity Score: {:.2f}%".format(max_similarity_nonfraud * 100))
    print("Sentence: ", nonfraud_sentences[max_index_nonfraud])
