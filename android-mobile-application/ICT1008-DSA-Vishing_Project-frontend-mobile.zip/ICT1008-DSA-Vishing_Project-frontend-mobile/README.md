# ICT1008-DSA-Vishing_Project Frontend Mobile Application

Minimum SDK: API 24 (Android 7.0 Nougat)
